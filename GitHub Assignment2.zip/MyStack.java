import java.util.ArrayList;

/**
 * @author Ugonna Umunna
 */

/**
 * A generic stack implementation using an array-based structure.
 * This stack follows the Last-In-First-Out (LIFO) principle.
 * It supports basic stack operations such as push, pop, checking if 
 * the stack is empty or full, and retrieving the size.
 * 
 * @param <T> the data type of elements stored in the stack
 */
public class MyStack<T> implements StackInterface<T> {
    private T[] stack;
    private int top;
    private int capacity;

    /**
     * Default constructor: Creates a stack with a default size of 10.
     */
    @SuppressWarnings("unchecked")
    public MyStack() {
        this.capacity = 10; // Default capacity
        this.stack = (T[]) new Object[capacity];
        this.top = -1; // Stack is initially empty
    }

    /**
     * Constructor: Creates a stack with a specified capacity.
     * 
     * @param size the maximum number of elements the stack can hold
     */
    @SuppressWarnings("unchecked")
    public MyStack(int size) {
        this.capacity = size;
        this.stack = (T[]) new Object[size];
        this.top = -1;
    }

    /**
     * Determines if the stack is empty.
     * 
     * @return {@code true} if the stack is empty, {@code false} otherwise.
     */
    @Override
    public boolean isEmpty() {
        return top == -1;
    }

    /**
     * Determines if the stack is full.
     * 
     * @return {@code true} if the stack is full, {@code false} otherwise.
     */
    @Override
    public boolean isFull() {
        return top == capacity - 1;
    }

    /**
     * Removes and returns the element at the top of the stack.
     * 
     * @return the element at the top of the stack.
     * @throws StackUnderflowException if the stack is empty.
     */
    @Override
    public T pop() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException("Stack is empty. Cannot pop.");
        }
        T element = stack[top]; // Get the top element
        stack[top] = null; // Help garbage collection
        top--; // Move top pointer down
        return element;
    }

    /**
     * Returns the element at the top of the stack without removing it.
     * 
     * @return the element at the top of the stack.
     * @throws StackUnderflowException if the stack is empty.
     */
    @Override
    public T top() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException("Stack is empty. Cannot retrieve top.");
        }
        return stack[top]; // Return top element without removing it
    }

    /**
     * Returns the number of elements currently in the stack.
     * 
     * @return the current number of elements in the stack.
     */
    @Override
    public int size() {
        return top + 1;
    }

    /**
     * Adds an element to the top of the stack.
     * 
     * @param e the element to add to the stack.
     * @return {@code true} if the element was successfully added.
     * @throws StackOverflowException if the stack is full.
     */
    @Override
    public boolean push(T e) throws StackOverflowException {
        if (isFull()) {
            throw new StackOverflowException("Stack is full. Cannot push.");
        }
        stack[++top] = e; // Move top pointer up and insert element
        return true;
    }

    /**
     * Returns a string representation of the stack from bottom to top.
     * 
     * @return a string representation of the stack.
     */
    @Override
    public String toString() {
        return toString(""); // Default delimiter is ", "
    }

    /**
     * Returns a string representation of the stack from bottom to top, 
     * with elements separated by a specified delimiter.
     * 
     * @param delimiter the delimiter to place between elements.
     * @return a string representation of the stack with elements separated by the delimiter.
     */
    @Override
    public String toString(String delimiter) {
        if (isEmpty()) return "";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i <= top; i++) {
            sb.append(stack[i]);
            if (i < top) sb.append(delimiter);
        }

        return sb.toString();
    }

    /**
     * Fills the stack with elements from an ArrayList.
     * A copy of the list is made to prevent external modification.
     * 
     * @param list elements to be added to the stack.
     * @throws StackOverflowException if adding elements exceeds stack capacity.
     */
    @Override
    public void fill(ArrayList<T> list) {
        for (T item : list) {
            if (isFull()) {
                throw new StackOverflowException("Stack overflow while filling.");
            }
            push(item);
        }
    }
}
