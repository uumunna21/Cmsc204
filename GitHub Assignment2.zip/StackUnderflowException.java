/**
 * @author Ugonna Umunna
 */

/**
 * Exception thrown when an attempt is made to pop or access the top 
 * element of an empty stack.
 * This exception is used in stack implementations to prevent 
 * removing or retrieving elements when the stack has no elements to process.
 */
public class StackUnderflowException extends RuntimeException {

	/**
     * Constructs a StackUnderflowException with a specified error message.
     * 
     * @param message the detail message describing the reason for the exception
     */
	public StackUnderflowException(String message)
	{
		super(message);
	}
}
