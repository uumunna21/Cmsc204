
import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;

/**
 * @author Ugonna Umunna
 */

/**
 * A utility class that provides methods for converting between infix and postfix 
 * notation, as well as evaluating postfix expressions.
 * This class uses a stack-based approach to perform these conversions and evaluations.
 */
public class Notation {

	/**
     * Converts an infix expression to postfix notation.
     * This method processes the infix expression character by character,
     * utilizing a queue for the postfix result and a stack for operators.
     * 
     * @param infix the infix expression as a string
     * @return the equivalent postfix expression as a string
     * @throws InvalidNotationFormatException if the infix expression contains mismatched parentheses or invalid characters
     */
    public static String convertInfixToPostfix(String infix) throws InvalidNotationFormatException {
        Stack<Character> operatorStack = new Stack<>();
        Queue<Character> postfixQueue = new LinkedList<>();
        
        for (char c : infix.toCharArray()) {
            if (Character.isWhitespace(c)) continue; // Ignore spaces
            
            if (Character.isDigit(c)) {
                postfixQueue.add(c); // Directly add operands to queue
            } else if (c == '(') {
                operatorStack.push(c); // Push left parenthesis
            } else if (c == ')') {
                // Pop from stack to queue until '(' is found
                while (!operatorStack.isEmpty() && operatorStack.peek() != '(') {
                    postfixQueue.add(operatorStack.pop());
                }
                if (operatorStack.isEmpty()) throw new InvalidNotationFormatException("Mismatched parentheses");
                operatorStack.pop(); // Remove '('
            } else if (isOperator(c)) {
                // Pop higher precedence operators from stack to queue
                while (!operatorStack.isEmpty() && precedence(operatorStack.peek()) >= precedence(c)) {
                    postfixQueue.add(operatorStack.pop());
                }
                operatorStack.push(c);
            } else {
                throw new InvalidNotationFormatException("Invalid character in expression");
            }
        }
        
        // Pop remaining operators from stack to queue
        while (!operatorStack.isEmpty()) {
            char op = operatorStack.pop();
            if (op == '(') throw new InvalidNotationFormatException("Mismatched parentheses");
            postfixQueue.add(op);
        }
        
        // Convert queue to string
        StringBuilder result = new StringBuilder();
        while (!postfixQueue.isEmpty()) {
            result.append(postfixQueue.poll()).append("");
        }
        return result.toString().trim();
    }

    /**
     * Converts a postfix expression to infix notation.
     * This method processes the postfix expression from left to right,
     * using a stack to reconstruct the equivalent infix expression.
     * 
     * @param postfix the postfix expression as a string
     * @return the equivalent infix expression as a string
     * @throws InvalidNotationFormatException if the postfix expression contains too many or too few operands
     */
    public static String convertPostfixToInfix(String postfix) throws InvalidNotationFormatException {
        Stack<String> stack = new Stack<>();
        
        for (char c : postfix.toCharArray()) {
            if (Character.isWhitespace(c)) continue; // Ignore spaces
            
            if (Character.isDigit(c)) {
                stack.push(String.valueOf(c)); // Push operands
            } else if (isOperator(c)) {
                if (stack.size() < 2) throw new InvalidNotationFormatException("Not enough operands");
                String b = stack.pop();
                String a = stack.pop();
                String expr = "(" + a + c + b + ")";
                stack.push(expr);
            } else {
                throw new InvalidNotationFormatException("Invalid character in expression");
            }
        }

        if (stack.size() != 1) throw new InvalidNotationFormatException("Too many operands");

        return stack.pop();
    }

    /**
     * Evaluates a postfix expression.
     * This method processes the postfix expression character by character,
     * using a stack to store intermediate results and perform operations.
     * 
     * @param postfix the postfix expression as a string
     * @return the evaluated result as a double
     * @throws InvalidNotationFormatException if the postfix expression contains invalid characters or incorrect formatting
     */
    public static double evaluatePostfixExpression(String postfix) throws InvalidNotationFormatException {
        Stack<Double> stack = new Stack<>();
        
        for (char c : postfix.toCharArray()) {
            if (Character.isWhitespace(c)) continue; // Ignore spaces
            
            if (Character.isDigit(c)) {
                stack.push((double) (c - '0')); // Convert char to number
            } else if (isOperator(c)) {
                if (stack.size() < 2) throw new InvalidNotationFormatException("Not enough operands");
                double b = stack.pop();
                double a = stack.pop();
                stack.push(applyOperation(a, b, c));
            } else {
                throw new InvalidNotationFormatException("Invalid character in expression");
            }
        }

        if (stack.size() != 1) throw new InvalidNotationFormatException("Too many operands");

        return stack.pop();
    }


    /**
     * Applies an arithmetic operation to two operands.
     * This method performs the specified operation based on the given operator.
     * 
     * @param a the first operand
     * @param b the second operand
     * @param op the operator character ('+', '-', '*', '/')
     * @return the result of the operation
     * @throws IllegalArgumentException if an invalid operator is provided
     */
    private static double applyOperation(double a, double b, char op) {
        switch (op) {
            case '+': return a + b;
            case '-': return a - b;
            case '*': return a * b;
            case '/': return a / b;
            default: throw new IllegalArgumentException("Invalid operator");
        }
    }

    /**
     * Checks if a character is a valid arithmetic operator.
     * 
     * @param c the character to check
     * @return {@code true} if the character is an operator, {@code false} otherwise
     */
    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }

    /**
     * Returns the precedence of an operator.
     * Higher precedence operators are evaluated first.
     * 
     * @param op the operator character ('+', '-', '*', '/')
     * @return an integer representing the precedence level (higher number = higher precedence)
     */
    private static int precedence(char op) {
        if (op == '+' || op == '-') return 1;
        if (op == '*' || op == '/') return 2;
        return -1;
    }
}

