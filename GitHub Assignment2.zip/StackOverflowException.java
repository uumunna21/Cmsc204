/**
 * @author Ugonna Umunna
 */

/**
 * Exception thrown when an attempt is made to push an element 
 * onto a full stack.
 * This exception is used in stack implementations to prevent 
 * adding elements beyond the stack's maximum capacity.
 */
public class StackOverflowException extends RuntimeException {
	
	 /**
     * Constructs a StackOverflowException with a specified error message.
     * 
     * @param message the detail message describing the reason for the exception
     */
	public StackOverflowException(String message)
	{
		super(message);
	}

}
