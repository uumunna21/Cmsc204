import java.util.ArrayList;

/**
 * @author Ugonna Umunna
 */


/**
 * A generic queue implementation using an array-based structure.
 * This queue follows the First-In-First-Out (FIFO) principle.
 * It supports basic queue operations such as enqueue, dequeue, 
 * checking if the queue is empty or full, and retrieving the size.
 * 
 * @param <T> the data type of elements stored in the queue
 */
public class MyQueue<T> implements QueueInterface<T> {
    
    /** The queue. */
    private T[] queue;
    
    /** The front. */
    private int front;
    
    /** The rear. */
    private int rear;
    
    /** The size. */
    private int size;
    
    /** The capacity. */
    private int capacity;
    
    
    /**
     * Default constructor: Creates an empty queue with an initial capacity of 0.
     * This constructor should be used cautiously as it initializes an empty queue.
     */
    
    @SuppressWarnings("unchecked")
	public MyQueue()
	{
		this.size = 0;
		this.capacity = size;
        this.queue = (T[]) new Object[size]; // Generic array creation
        this.front = 0;
        this.rear = -1;
		
	}

    /**
     * Constructor: Creates a queue with a specified size.
     * 
     * @param size the maximum number of elements the queue can hold
     */
    @SuppressWarnings("unchecked")
    public MyQueue(int size) {
        this.capacity = size;
        this.queue = (T[]) new Object[size]; // Generic array creation
        this.front = 0;
        this.rear = -1;
        this.size = 0;
    }

    /**
     * Determines if the queue is empty.
     * 
     * @return {@code true} if the queue is empty, {@code false} otherwise.
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Determines if the queue is full.
     * 
     * @return {@code true} if the queue is full, {@code false} otherwise.
     */
    @Override
    public boolean isFull() {
        return size == capacity;
    }

    /**
     * Deletes and returns the element at the front of the queue.
     * 
     * @return the element at the front of the queue.
     * @throws QueueUnderflowException if the queue is empty.
     */
    @Override
    public T dequeue() throws QueueUnderflowException {
        if (isEmpty()) {
            throw new QueueUnderflowException("Queue is empty. Cannot dequeue.");
        }

        T frontElement = queue[front]; // Get front element
        queue[front] = null; // Help garbage collection
        front = (front + 1) % capacity; // Move front (circular behavior)
        size--;

        return frontElement;
    }

    /**
     * Returns the number of elements currently in the queue.
     * 
     * @return the current number of elements in the queue.
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * Adds an element to the end of the queue.
     * 
     * @param e the element to add to the queue.
     * @return {@code true} if the element was successfully added.
     * @throws QueueOverflowException if the queue is full.
     */
    @Override
    public boolean enqueue(T e) throws QueueOverflowException {
        if (isFull()) {
            throw new QueueOverflowException("Queue is full. Cannot enqueue.");
        }

        rear = (rear + 1) % capacity; // Move rear index (circular behavior)
        queue[rear] = e;
        size++;

        return true;
    }

    /**
     * Returns a string representation of the queue elements.
     * The beginning of the string represents the front of the queue.
     * Elements are separated by an empty delimiter.
     * 
     * @return a string representation of the queue elements.
     */
    @Override
    public String toString() {
        return toString(""); // Default delimiter
    }

    /**
     * Returns a string representation of the queue elements with a specified delimiter.
     * The beginning of the string represents the front of the queue.
     * 
     * @param delimiter the delimiter to place between elements.
     * @return a string representation of the queue elements separated by the delimiter.
     */
    @Override
    public String toString(String delimiter) {
        if (isEmpty()) return ""; // Return empty string if no elements

        StringBuilder sb = new StringBuilder();
        int index = front;

        for (int i = 0; i < size; i++) {
            sb.append(queue[index]);
            if (i < size - 1) sb.append(delimiter);
            index = (index + 1) % capacity; // Circular traversal
        }

        return sb.toString();
    }

    /**
     * Fills the queue with elements from an ArrayList.
     * A copy of the list is made to prevent external modification.
     * 
     * @param list the ArrayList whose elements should be added to the queue.
     * @throws QueueOverflowException if adding elements exceeds queue capacity.
     */
    @Override
    public void fill(ArrayList<T> list) {
        for (T item : list) {
            if (isFull()) {
                throw new QueueOverflowException("Queue overflow while filling.");
            }
            enqueue(item);
        }
    }

	
}

