/**
 * @author Ugonna Umunna
 */

/**
 * Exception thrown when an attempt is made to dequeue an element 
 * from an empty queue.
 * This exception is used in queue implementations to prevent 
 * removing elements when the queue has no elements to retrieve.
 */
public class QueueUnderflowException extends RuntimeException {
	
	/**
     * Constructs a QueueUnderflowException with a specified error message.
     * 
     * @param message the detail message describing the reason for the exception
     */
	public QueueUnderflowException(String message) {
		super(message);
	}

}
