/**
 * @author Ugonna Umunna
 */

/**
 * Exception thrown when an attempt is made to enqueue an element 
 * into a full queue.
 * This exception is used in queue implementations to prevent 
 * adding elements beyond the queue's capacity.
 */
public class QueueOverflowException extends RuntimeException {
	
	/**
     * Constructs a QueueOverflowException with a specified error message.
     * 
     * @param message the detail message describing the reason for the exception
     */
	public QueueOverflowException(String message) {
		super(message);
	}

}
