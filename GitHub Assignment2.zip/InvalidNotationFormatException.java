
/**
 * @author Ugonna Umunna
 */

/**
 * Exception thrown when a notation format is invalid.
 * This exception is used to indicate errors in the conversion 
 * of infix, postfix, or other notation expressions.
 */

public class InvalidNotationFormatException extends RuntimeException {
	
	/**
     * Constructs an InvalidNotationFormatException with a specified error message.
     * 
     * @param message the detail message describing the reason for the exception
     */
	public InvalidNotationFormatException(String message){
		super(message);
	}

}
