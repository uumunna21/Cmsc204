package StackExercise;

public class ArrayStack<T> implements StackInterface<T> {
	private T[] stack;
	private int topIndex;
	private int capacity;

	public ArrayStack(int size) {
		stack = (T[]) new Object[size];
		topIndex = -1;
		capacity = size;
	}

	@Override
	public void push(T data) throws RuntimeException {
		if (topIndex == capacity - 1)
			throw new RuntimeException("Stack overflow");
		stack[++topIndex] = data;
	}

	@Override
	public T pop() throws RuntimeException {
		if(isEmpty)
		{
			throw new RuntimeException("Stack overflow");
		}
		
		T element = stack[topIndex];
		stack[topIndex] = null;
		topIndex--;
		
		return element;
	}

	@Override
	public T peek() throws RuntimeException {
	
		if(isEmpty)
		{
			throw new RuntimeException("Stack overflow");
		}
		
		T element = stack[topIndex];

		return element;
	}

	@Override
	public boolean isEmpty() {

		return (topIndex == -1);
	}

	@Override
	public void clear() {
		// Remove references to the objects in the stack,
		// but do not deallocate the array
		//TO be completed

	}
}