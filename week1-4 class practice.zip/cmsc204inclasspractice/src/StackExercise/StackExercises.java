package StackExercise;
import java.util.Stack;

public class StackExercises {

	public static void main(String[] args) {
	
	}
	
	/*
	 *  Write a program to reverse a string using a stack.
				Example Input/Output:

		Input: "hello"
		Output: "olleh"
		Hint:

		Push each character onto the stack.
		pop characters one by one to get the reversed string.
		
		public static String reverseString(String str)
	 */
	
	public static String reverseString(String str)
	{
		Stack<Character> stack = new Stack<>();
		
		for(int i = 0; i < str.length(); i++)
		{
			stack.push(str.charAt(i));
		}
		
		String newStr = "";
		
		while(!stack.isEmpty())
		{
			newStr += stack.pop();
		}
		
		return newStr;
		
	}
	
	/**
	 * For a given array, find the next greater element (NGE) for each element. 
	 * If there is no greater element, return -1.
		Example Input/Output:

		Input: [4, 5, 2, 10, 8]  
		Output: [5, 10, 10, -1, -1]  
		Hint:
		Traverse the array from right to left.
		Use a stack to store potential NGEs.
		
		public static void findNextGreaterElements(int[] arr) 
	 */
		 
	
	

}

