package StackExercise;
public class StackExample {
    public static void main(String[] args) {
        ArrayStack<Integer> stack = new ArrayStack<>(4);

        // Push elements
        stack.push(10);
        stack.push(20);
        stack.push(30);
        System.out.println("Stack after pushes: " + stack);

        // Peek element
        System.out.println("Top element: " + stack.peek());

        // Pop element
        System.out.println("Popped element: " + stack.pop());
        System.out.println("Stack after pop: " + stack);
        /*
         * Pop 3 more elements
         */
        
        /**
         * Create a stack using LinkedStack of type String
         * add 3 names
         * pop 2 names 
         * pop 2 more
         */
        
    }
}
