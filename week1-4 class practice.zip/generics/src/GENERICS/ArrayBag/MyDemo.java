package GENERICS.ArrayBag;



public class MyDemo {

	public static void main(String[] args) {
		 
		ArrayBag<String>  myBag = new ArrayBag<String>();
		myBag.add("Milk");
		myBag.add("Bread");
		myBag.add("Egg");
		myBag.add("apple");
		//String myItem = myBag.remove();
		myBag.remove("Egg");
		
		
		Object[] temp = myBag.toArray();
		for (Object item : temp)
		{
			System.out.println(item);

		}
		ArrayBag<Item>  anotherBag = new ArrayBag<Item>();
		
		Item it = new Item("Milk", "1011");
		anotherBag.add(it);
		anotherBag.add(new Item ("Bread", "1234"));
		anotherBag.remove(new Item ("Bread", "1234"));
		
		temp = anotherBag.toArray();
		for (Object i : temp)
		{
			System.out.println(i);
		}

	}
}
