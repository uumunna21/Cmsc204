package GENERICS.ArrayBag;

public class Item {
	public String name;
	public String barCode;
	
	public Item(String name, String barCode)
	{
		this.name = name;
		this.barCode = barCode;
	}
	
	@Override
	public String toString()
	{
		return name + " " + barCode;
	}
	@Override
	public boolean equals(Object anotherObject)
	{
		Item another = (Item) anotherObject;
		return this.name.equals(another.name) && 
				   this.barCode.equals(another.barCode);
	}

}
