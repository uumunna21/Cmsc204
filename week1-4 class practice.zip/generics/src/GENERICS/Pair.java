package GENERICS;
public class Pair<T> implements Pairable<T> {
    private T first;
    private T second;

    public Pair(T first, T second) {
        this.first = first;
        this.second = second;
    }

    public T getFirst() { return first; }
    public T getSecond() { return second; }

    public void swap() {
        T temp = first;
        first = second;
        second = temp;
    }
}