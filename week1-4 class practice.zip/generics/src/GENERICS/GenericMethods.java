package GENERICS;
public class GenericMethods {
    public static <T> void printArray(T[] array) {
        for (T item : array) {
            System.out.print(item + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Integer[] intArray = {1, 2, 3, 4, 5};
        String[] strArray = {"Hello", "World", "Generics"};
        Double[] dblArray = {1.1, 2.2, 3.3};

        System.out.print("Integer Array: ");
        printArray(intArray);
        
        System.out.print("String Array: ");
        printArray(strArray);

        System.out.print("Double Array: ");
        printArray(dblArray);
        
        Bankaccount[] bank1 = new Bankaccount();
        
        
       }
}