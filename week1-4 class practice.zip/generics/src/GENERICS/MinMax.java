package GENERICS;
public class MinMax<T extends Comparable<T>> {
    private T[] values;

    public MinMax(T[] values) {
        this.values = values;
    }

    public T getMin() {
        T min = values[0];
        for (T item : values) {
            if (item.compareTo(min) < 0) {
                min = item;
            }
        }
        return min;
    }

    public T getMax() {
        T max = values[0];
        for (T item : values) {
            if (item.compareTo(max) > 0) {
                max = item;
            }
        }
        return max;
    }

    public static void main(String[] args) {
        Integer[] numbers = {3, 7, 2, 9, 5};
        MinMax<Integer> minMax = new MinMax<>(numbers);

        System.out.println("Min: " + minMax.getMin());
        System.out.println("Max: " + minMax.getMax());
    }
}