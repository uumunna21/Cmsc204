package GENERICS;
public interface Pairable<T> {
    T getFirst();
    T getSecond();
    void swap();
}