package GENERICS;

public class PairableDemo{	
	public static void main(String[] args) {
		Pair a = new Pair(1, 2);
	}
}
