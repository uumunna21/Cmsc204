
public class NoSpecialCharacterException extends Exception {
	public NoSpecialCharacterException(){
		super("The password cannot contain more than two of the same character in sequence.");
	}
}
