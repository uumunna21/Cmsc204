import java.io.*;

import java.util.*;
import java.math.*;
import java.awt.*;
import java.lang.*;

public class PasswordCheckerUtility{
	public static void comparePasswords(String password, String passwordConfirm) throws UnmatchedException{
		if(!password.equals(passwordConfirm)) {
			throw new UnmatchedException();
		}
	}
	public static boolean comparePasswordsWithReturn(String password, String passwordConfirm){
		return (password.equals(passwordConfirm));
	}
	public static ArrayList<String> getInvalidPasswords(ArrayList<String> passwords){
		ArrayList<String> arr = new ArrayList<String>();
		for(String p : passwords) {
			try{
				isValidPassword(p);
			}catch(Exception e) {
				arr.add(p + " " + e.getMessage());
			}
		}
		return arr;
	}
	public static boolean hasBetweenSixAndNineChars(String password) throws WeakPasswordException{
		if(!(password.length() <= 9 && password.length() >= 6)) throw new WeakPasswordException();
		return (password.length() <= 9 && password.length() >= 6);
	}
	public static boolean hasDigit(String password) throws NoSpecialCharacterException{
		for(int i = 0; i < password.length(); i++) {
			if(Character.isDigit(password.charAt(i))) { 
				return true;
			}
		}
		throw new NoSpecialCharacterException();
	}
	public static boolean hasLowerAlpha(String password) throws NoLowerAlphaException{
		for(int i = 0; i < password.length(); i++) {
			if(Character.isLowerCase(password.charAt(i))) { 
				return true;
			}
		}
		throw new NoLowerAlphaException();
	}
	public static boolean hasSpecialChar(String password) throws NoSpecialCharacterException{
		String special = "~`!@#$%^&*()_+-=[]{}|;':,./<>?";
		for(int x = 0; x < password.length(); x++) {
			for(int y = 0; y < special.length(); y++) {
				String a = "" + password.charAt(x);
				String b = "" + special.charAt(y);
				if(a.equals(b)) { 
					throw new NoSpecialCharacterException();
				}
			}
		}
		return true;
	}
	public static boolean hasUpperAlpha(String password) throws NoUpperAlphaException{
		for(int i = 0; i < password.length(); i++) {
			if(Character.isUpperCase(password.charAt(i))) { 
				return true;
			}
		}
		throw new NoUpperAlphaException();
	}
	public static boolean isValidLength(String password) throws LengthException{
		if((password.length() < 6)) throw new LengthException();
		return (password.length() >= 6);
	}
	public static boolean isValidPassword(String password) throws NoUpperAlphaException, NoLowerAlphaException, NoSpecialCharacterException, InvalidSequenceException, LengthException{
		return (hasUpperAlpha(password) && hasLowerAlpha(password) && hasDigit(password) && hasSpecialChar(password) && NoSameCharInSequence(password) && isValidLength(password));
	}
	public static boolean isWeakPassword(String password) throws WeakPasswordException, NoUpperAlphaException, NoLowerAlphaException, NoSpecialCharacterException, InvalidSequenceException, LengthException{
		if(hasUpperAlpha(password) && hasLowerAlpha(password) && hasDigit(password) && hasSpecialChar(password) && NoSameCharInSequence(password) && isValidLength(password) && hasBetweenSixAndNineChars(password)) {
			return true;
		}
		else {
			throw new WeakPasswordException();
		}
	}
	public static boolean NoSameCharInSequence(String password) throws InvalidSequenceException{
		for(int i = 1; i < password.length(); i++) {
			if(password.charAt(i-1) == password.charAt(i)) {
				i = password.length();
				throw new InvalidSequenceException();
			}
		}
		return true;
	}
}
