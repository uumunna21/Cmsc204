package QUEUEPractice;
import java.util.Deque;
import java.util.LinkedList;

public class DequeAsQueue {
    public static void main(String[] args) {
        Deque<Integer> queue = new LinkedList<>();
        
        queue.addLast(10);
        queue.addLast(20);
        queue.addLast(30);
        System.out.println("Queue: " + queue);
        
        System.out.println("Front element: " + queue.getFirst());
        System.out.println("Dequeued element: " + queue.removeFirst());
        System.out.println("Queue after dequeue: " + queue);
    }
}
