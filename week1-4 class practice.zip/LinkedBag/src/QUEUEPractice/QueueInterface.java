package Queue.Questions;

public interface QueueInterface<T> {
    public void enqueue(T data) throws RuntimeException;
    public T dequeue();
    public T getFront();
    public boolean isEmpty();
}