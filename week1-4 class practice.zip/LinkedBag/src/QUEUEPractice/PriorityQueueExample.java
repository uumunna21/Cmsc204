package QUEUEPractice;
import java.util.PriorityQueue;

public class PriorityQueueExample {
    public static void main(String[] args) {
        PriorityQueue<Integer> pq = new PriorityQueue<>();
        PriorityQueue<Person> pr = new PriorityQueue<>();

        pr.add(new Person("James"));
        pr.add(new Person("Run"));
        pr.add(new Person("Kim"));
        System.out.println("Priority Queue: " + pr);



        
        pq.add(30);
        pq.add(10);
        pq.add(20);
        System.out.println("Priority Queue: " + pq);
        
        System.out.println("Dequeued Element: " + pq.poll());
        System.out.println("Priority Queue after poll: " + pq);
    }
}
