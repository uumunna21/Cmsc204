package QUEUEPractice;

class ArrayQueue<T> implements QueueInterface<T> {
	private T[] queue;
	private int front, rear, size, capacity;

	public ArrayQueue(int capacity) {
		this.capacity = capacity;
		queue = (T[]) new Object[capacity];
		front = 0;
		rear = -1;
		size = 0;
	}

	@Override
	public void enqueue(T data) throws  RuntimeException {
		if (size == capacity)
			throw new RuntimeException("Queue is full");

		rear = (rear + 1) % capacity;
		queue[rear] = data;
		size++;
		
		
	}

	@Override
	public T dequeue() throws RuntimeException {
		if (size == 0)
			throw new RuntimeException("Queue is empty");
		
	}

	@Override
	public T getFront() {
		//TO BE COMPLETED
	}

	@Override
	public boolean isEmpty() {

		//TO BE COMPLETED
	}
}