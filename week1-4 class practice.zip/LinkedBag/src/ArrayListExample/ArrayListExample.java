package ArrayListExample;
import java.util.ArrayList;

public class ArrayListExample {
    public static void main(String[] args) {
        // Create an ArrayList of Strings
        ArrayList<String> tasks = new ArrayList<>();

        // Adding elements
        tasks.add("Complete homework");
        tasks.add("Go grocery shopping");
        tasks.add("Read a book");

        // Insert an element at index 1
        tasks.add(1, "Pay bills");

        // Display the list
        System.out.println("Tasks: " + tasks);

        // Get an element at a specific index
        System.out.println("Task at index 2: " + tasks.get(2));

        // Replace an element
        tasks.set(0, "Finish Java project");
        System.out.println("After replacing first task: " + tasks);

        // Remove an element
        tasks.remove("Read a book");
        System.out.println("After removing a task: " + tasks);

        // Check if the list contains a task
        System.out.println("Contains 'Go grocery shopping'? " + tasks.contains("Go grocery shopping"));

        // Size of the list
        System.out.println("Total tasks: " + tasks.size());

        // Looping through the list
        System.out.println("All tasks:");
        for (String task : tasks) {
            System.out.println(task);
        }
    }
}
