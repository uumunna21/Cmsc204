package ArrayListExample;
import java.util.LinkedList;

public class LinkedListExample {
    public static void main(String[] args) {
        // Create a LinkedList of integers
        LinkedList<String> books = new LinkedList<>();

        // Adding elements
        books.add("The Great Gatsby");
        books.add("To Kill a Mockingbird");
        books.add("1984");

        // Add elements at the beginning and end
        books.addFirst("Moby Dick");
        books.addLast("War and Peace");

        // Display the list
        System.out.println("Books: " + books);

        // Get and remove the first element
        System.out.println("First book: " + books.getFirst());
        System.out.println("Removed first book: " + books.removeFirst());

        // Get and remove the last element
        System.out.println("Last book: " + books.getLast());
        System.out.println("Removed last book: " + books.removeLast());

        // Display the modified list
        System.out.println("Updated book list: " + books);
    }
}
