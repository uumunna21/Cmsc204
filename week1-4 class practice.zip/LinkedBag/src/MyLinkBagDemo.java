package ADT_BAG.LinkedBag;

import ADT_BAG.ArrayBag.BagInterface;
import ADT_BAG.MyDemo.Person;

public class MyLinkBagDemo {

	public static void main(String[] args) {

		BagInterface<String> myBag = new LinkedBag<String>();

		myBag.add("Egg");
		myBag.add("Bread");
		myBag.add("Milk");
		myBag.add("orange");
		
		//myBag.remove();
		Object[] items = myBag.toArray();

		for (Object i : items)
			System.out.print(i + " ");
		 
		// An Array Bag of Person ?Q!
		// Why not ArrayBag can contain any type of object
		LinkedBag<Person> people = new LinkedBag<Person>();
		people.add(new Person(10));
		people.add(new Person(4));
		people.add(new Person(23));
		people.add(new Person(40));

		// returns an array of Person
		Person[] pArray = people.toArray();

		// Display items
		for (Person p : pArray)
			System.out.println(p);

//		people.remove();
//
//		System.out.println("After Remove");
//
//		items = people.toArray();
//		// Display items
//		for (Object i : items)
//			System.out.println(i);
//
//		people.remove(new Person(10));
//
//		System.out.println("After Remove");
//		items = people.toArray();
//		// Display items
//		for (Object i : items)
//			System.out.println(i);
//		// Did it Work?
	}

}
