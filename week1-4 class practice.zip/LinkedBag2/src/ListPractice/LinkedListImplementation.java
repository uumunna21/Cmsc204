package ListPractice;
import java.util.List;
import java.util.ListIterator;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkedListImplementation<T> implements List<T> {
     

    private Node<T> head;
    private int size;

    public LinkedListImplementation() {
        this.head = null;
        this.size = 0;
    }

    @Override
    public boolean add(T data) {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
        } else {
            Node<T> temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
        size++;
        return true;
    }

    @Override
    public void add(int index, T data) {
        if (index < 0 || index > size) throw new IndexOutOfBoundsException();
        Node<T> newNode = new Node<>(data);
        if (index == 0) {
            newNode.next = head;
            head = newNode;
        } else {
        	Node<T> temp = head;
        	while(temp.next != null)
        	{
        		temp = temp.next;
        	}
        	temp.next = newNode;
        }
        size++;
    }

    @Override
    public T get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        Node<T> temp = head;
        //TO BE COMPLETED
    }

    @Override
    public T set(int index, T data) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        Node<T> temp = head;
//        for (int i = 0; i < index; i++) {
//            temp = temp.next;
//        }
//        T oldData = temp.data;
//        temp.data = data;
//        return oldData;
    }

    @Override
    public T remove(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        T removedData;
        if (index == 0) {
            removedData = head.data;
            head = head.next;
        } else {
           //TO BE COMPLETED
        }
        size--;
        return removedData;
    }

    @Override
    public boolean remove(Object o) {
        if (head == null) return false;
        if (head.data.equals(o)) {
            head = head.next;
            size--;
            return true;
        }
        Node<T> temp = head;
       //TO BE COMPLETED
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public boolean contains(Object o) {
    	//TO BE COMPLETED
    }

    @Override
    public void clear() {
        head = null;
        size = 0;
    }

    @Override
    public Object[] toArray() {
        Object[] array = new Object[size];
        Node<T> temp = head;
        int i = 0;
        while (temp != null) {
            array[i++] = temp.data;
            temp = temp.next;
        }
        return array;
    }

    @Override
    public String toString() {
    	return null;  //Should eventually be completed
    }
    private static class Node<T> {
        T data;
        Node<T> next;
        
        Node(T data) {
            this.data = data;
            this.next = null;
        }
    }

	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> T[] toArray(T[] a) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addAll(Collection<? extends T> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addAll(int index, Collection<? extends T> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int indexOf(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int lastIndexOf(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ListIterator<T> listIterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ListIterator<T> listIterator(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<T> subList(int fromIndex, int toIndex) {
		// TODO Auto-generated method stub
		return null;
	}

    
}
