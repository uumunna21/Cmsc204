package ListPractice;

import java.util.List;

public class TestListImplementation {
    public static void main(String[] args) {
        List<Integer> list = new LinkedListImplementation<>();
        
        list.add(10);
        list.add(20);
        list.add(30);
        System.out.println("List after adding elements: " + list);

        list.add(1, 15);
        System.out.println("After inserting 15 at index 1: " + list);

        System.out.println("Element at index 2: " + list.get(2));

        list.set(2, 25);
        System.out.println("After setting index 2 to 25: " + list);

        list.remove(3);
        System.out.println("After removing element at index 3: " + list);

        System.out.println("List contains 20? " + list.contains(20));
        System.out.println("List size: " + list.size());

        list.clear();
        System.out.println("After clearing list: " + list);
        
        
        /* 
         * EXPECTED OUTPUT:
         * List after adding elements: [10, 20, 30]
			After inserting 15 at index 1: [10, 15, 20, 30]
			Element at index 2: 20
			After setting index 2 to 25: [10, 15, 25, 30]
			After removing element at index 3: [10, 15, 25]
			List contains 20? false
			List size: 3
			After clearing list: []
         */
    }
}