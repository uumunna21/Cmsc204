/*
 * generic Node class represents an element in the linked bag
 * 
 */
public class Node<T> {
    T data; //field to store an item
    Node<T> next; //reference to the next node in the chain

    /*
     *  constructor that initializes both fields.
     */
    public Node(T data, Node<T> next) {
        this.data = data;  
        this.next = next;  
    }

    public T getData() {
        return data;
    }

    public Node<T> getNext() {
        return next;
    }

    public void setNext(Node<T> next) {
        this.next = next;
    }
}
