public class LinkedBagTest {
    public static void main(String[] args) {
        LinkedBag<String> bag = new LinkedBag<>();

        bag.add("Apple");
        bag.add("Banana");
        bag.add("Cherry");
        bag.add("Apple");
        bag.add("Banana");

        System.out.println("Bag contents:");
        Object[] bagArray = bag.toArray();
		for (int index = 0; index < bagArray.length; index++)
		{
			System.out.print(bagArray[index] + " ->");
		} //
		System.out.println();
        System.out.println("Contains 'Apple'? " + bag.contains("Apple"));
        System.out.println("Frequency of 'Banana': " + bag.getFrequencyOf("Banana"));

        bag.remove("Apple");
        System.out.println("After removing 'Apple':");
        
        bagArray = bag.toArray();
		for (int index = 0; index < bagArray.length; index++)
		{
			System.out.print(bagArray[index] + " ->");
		} // end for
    }
    /*
     * Expected output:
     * Bag contents:
		Banana -> Apple -> Cherry -> Banana -> Apple 
		Contains 'Apple'? true
		Frequency of 'Banana': 2
		After removing 'Apple':
		Banana -> Cherry -> Banana -> Apple  
     * 
     */
}
