 

/*
 * LinkedBag<T> class that stores items using a linked structure
 */
public class LinkedBag<T> {
    private Node<T> head;
    private int size;

    public LinkedBag() {
        head = null;
        size = 0;
    }

    /** Adds a new entry at the beginning of the list
     * 
     * @param newEntry data to be added
     * @return true
     */
    public boolean add(T newEntry) {
        Node<T> newNode = new Node<>(newEntry, head); //Create a new Node
        //TO BE COMPLETED
    }

    /** Checks if the bag contains a given entry
     * 
     * @param entry
     * @return true or false
     */
    public boolean contains(T entry) {
        Node<T> current = head;
        {
            boolean found = false;
            
            while (!found && (current != null))
            {
               if (entry.equals(current.data))
                  found = true;
               else
                  current = current.next;
            } // end while
            return found;
         } // end contains
        
    }
    
    
    /** Removes and returns the first element in the bag
     * 
     * @return the element or null if chain is empty
     */
    public T remove() {
        if (head == null) {  // If bag is empty
            return null;
        }
        
        {
    	  T result = null;
          if (firstNode != null)
          {
             result = firstNode.data; 
             firstNode = firstNode.next; // Remove first node from chain
             numberOfEntries--;
          } // end if

    		return result;
    	} // end remove

        
        
    }

    /** Removes the first occurrence of an entry and decrease the size of list
     * return true if entry is found , false otherwise
     */
    public boolean remove(T entry) {
        if (head == null) return false;  // Empty bag

        //TO BE COMPLETED
    }

    /** 
     * Counts occurrences of a given entry
     */
    public int getFrequencyOf(T entry) {
        int count = 0;
        Node<T> current = head;
        
		int frequency = 0;
		while ((count < size) && (current != null))
        {
           if (entry.equals(current.data))
           {
              frequency ++;
           } // end if
           
           count++;
           current = current.next;
        } // end while

  		return frequency;
  	} // end getFrequencyOf


    }

   /** Retrieves all entries that are in this bag.
    @return  A newly allocated array of all the entries in this bag.
    */
    public T[] toArray() {
    	if (size == 0)
    		return null;
    	   //TO BE COMPLETED
    }
}
